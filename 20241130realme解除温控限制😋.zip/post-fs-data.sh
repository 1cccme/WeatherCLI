MODDIR=${0%/*}
mount --bind $MODDIR/odm/etc/temperature_profile/sys_high_temp_protect_realme_22623.xml /odm/etc/temperature_profile/sys_high_temp_protect_realme_22623.xml

mount --bind $MODDIR/odm/etc/temperature_profile/sys_thermal_control_config.xml /odm/etc/temperature_profile/sys_thermal_control_config.xml

mount --bind $MODDIR/odm/etc/temperature_profile/sys_thermal_control_config_gt.xml /odm/etc/temperature_profile/sys_thermal_control_config_gt.xml

mount --bind $MODDIR/odm/etc/ThermalServiceConfig /odm/etc/ThermalServiceConfig

mount --bind $MODDIR/odm/firmware/fastchg/22623/bms_heating_config.txt /odm/firmware/fastchg/22623/bms_heating_config.txt