# 关闭温控解除限制
while :
do
    setprop init.svc.thermal-engine stopped
    setprop init.svc.android.thermal-hal stopped
    echo "0 37000" > /proc/shell-temp
    echo "1 37000" > /proc/shell-temp
    echo "2 37000" > /proc/shell-temp
    sleep 60
done